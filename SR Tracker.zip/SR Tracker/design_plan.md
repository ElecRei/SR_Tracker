#Design Plan

The SR Tracker should match Overwatch design-wise from the graphic interface to the font to the color schemes. So some goals:

- Find out what the Overwatch font is for the:
    - Headers
    - Menus
    
- Find out the basic color scheme of the main menu, maybe competitives(?):
    - Take screen shot and just eyedrop away

- For the interface design:
    - Screenshot the main menu and maybe sub-menus
    - Try and see what's emulatable by code and what will need to be graphics